<?php $active_menu=1;?>
<!DOCTYPE html>
<html lang="en-US">

<!-- /reo-services30 Nov 2022 15:29:50 GMT -->

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <title>Hydeman &raquo; Software Development</title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <script type='text/javascript'
        src='../../platform-api.sharethis.com/js/sharethis.js#property=5f1a18d239b2000012b4ac9c&product=sop'
        async='async'></script>


    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56933142-1"></script>



    <meta name='robots' content='max-image-preview:large' />
    <link rel='dns-prefetch' href='http://www.google.com/' />
    <link rel='stylesheet' id='flexslider-css'
        href='../wp-content/themes/devsavvy/plugins/flexslider/flexslider8d5a.css?ver=2.4.0' type='text/css'
        media='all' />
    <link rel='stylesheet' id='site-css' href='../wp-content/themes/devsavvy/style.mina9d1.css?ver=1614733405082'
        type='text/css' media='all' />
    <link rel='stylesheet' id='wp-block-library-css'
        href='../wp-includes/css/dist/block-library/style.min6a4d.css?ver=6.1.1' type='text/css' media='all' />
    <link rel='stylesheet' id='classic-theme-styles-css' href='../wp-includes/css/classic-themes.min68b3.css?ver=1'
        type='text/css' media='all' />
    <style id='global-styles-inline-css' type='text/css'>
        body {
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
            --wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');
            --wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');
            --wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');
            --wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');
            --wp--preset--duotone--midnight: url('#wp-duotone-midnight');
            --wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');
            --wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');
            --wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');
            --wp--preset--font-size--small: 13px;
            --wp--preset--font-size--medium: 20px;
            --wp--preset--font-size--large: 36px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
        }

        :where(.is-layout-flex) {
            gap: 0.5em;
        }

        body .is-layout-flow>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-flow>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-flow>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-constrained>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-constrained>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
            max-width: var(--wp--style--global--content-size);
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignwide {
            max-width: var(--wp--style--global--wide-size);
        }

        body .is-layout-flex {
            display: flex;
        }

        body .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        body .is-layout-flex>* {
            margin: 0;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        .wp-block-navigation a:where(:not(.wp-element-button)) {
            color: inherit;
        }

        :where(.wp-block-columns.is-layout-flex) {
            gap: 2em;
        }

        .wp-block-pullquote {
            font-size: 1.5em;
            line-height: 1.6;
        }
    </style>
    <link rel='stylesheet' id='ctct_form_styles-css'
        href='../wp-content/plugins/constant-contact-forms/assets/css/style1dd9.css?ver=1.13.0' type='text/css'
        media='all' />
    <link rel='stylesheet' id='popup-maker-site-css'
        href='../wp-content/uploads/pum/pum-site-stylese605.css?generated=1668451767&amp;ver=1.16.14' type='text/css'
        media='all' />
    <script type='text/javascript' src='../wp-includes/js/jquery/jquery.mina7a0.js?ver=3.6.1'
        id='jquery-core-js'></script>
    <script type='text/javascript' src='../wp-includes/js/jquery/jquery-migrate.mind617.js?ver=3.3.2'
        id='jquery-migrate-js'></script>
    <script type='text/javascript'
        src='../wp-content/themes/devsavvy/plugins/flexslider/jquery.flexslider8d5a.js?ver=2.4.0'
        id='flexslider-js'></script>
    <script type='text/javascript' src='../wp-content/themes/devsavvy/js/onloada9d1.js?ver=1614733405082'
        id='site-js'></script>
    <link rel="canonical" href="https://hydemandevelopment.com/" />
    <link rel="shortcut icon" href="../wp-content/themes/devsavvy/images/favicon.png" type="image/x-icon" />
</head>

<body class="page-template-default page page-id-316 ctct-devsavvy page-reo-services">
    <div id="wrapper">
        <?php include('../header.php')?>
        <section class="alert">
            <div class="a-content">
                Proudly Serving The Commercial Real Estate Industry For Over 40 Years
            </div>
        </section>


        <main>

            <section class="services-nav">

                <div class="container">

                    <div class="menu-services-nav-menu-container">
                        <ul id="menu-services-nav-menu" class="menu">
                            <li id="menu-item-514"
                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-514"><a
                                    href="../commercial-brokerage/">Commercial<br>Brokerage</a></li>
                            <li id="menu-item-513"
                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-513"><a
                                    href="../property-management/">Property<br>Management</a></li>
                            <li id="menu-item-512"
                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-512"><a
                                    href="../asset-management-financial-services/">Asset Management<br>&#038;
                                    Financial Services</a></li>
                            <li id="menu-item-511"
                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-511"><a
                                    href="../construction-project-management/">Construction<br>Project
                                    Management</a></li>
                            <li id="menu-item-510"
                                class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-316 current_page_item menu-item-510">
                                <a href="#" aria-current="page">Software<br>Development</a></li>
                            <li id="menu-item-509"
                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-509"><a
                                    href="../readymade-garments/">Readymade<br>Garments</a>
                            </li>
                        </ul>
                    </div>
                </div>


            </section>



            <section class="hero" style=" background-image: url('../wp-content/uploads/2020/07/accent-reo.jpg');">

                <div class="container">

                    <div class="big svc">

                        <div class="hero-holder">
                            <p><img decoding="async" class="svc-icon"
                                    src="../wp-content/uploads/2020/07/icon-reo-services.png" alt="REO Services" /></p>
                            <h1>Software Development</h1>
                            <div style="clear: both;"></div>
                            <p>Hydeman Development has undertaken a new initiative to serve West-Northwest Canada with
                                the latest form of Software to maximize the utilization of both in the Public and
                                Private Sector. We can develop, manage and maintain the software including mobile
                                applications, games (2D,3D,AR,VR games),websites, AR VR based solutions, 3D modeling
                                ,machine learning(ML) based applications, artificial intelligence based software and
                                blockchain aplications.</p>
                            <p>Apart from Canadian Software developers, our partners include the leading software
                                developers of the USA, Bangladesh and India. </p>
                        </div>


                    </div>

                </div>


            </section>



            <section class="services-content">

                <div class="container">

                    <div class="mx-auto" style="max-width: 100%;">

                        <div class="content-holder">
                            <div class="content-text">
                                <h3>Services Offered</h3>
                                <ul>
                                    <li>Web Development</li>
                                    <li>Mobile Applications</li>
                                    <li>AR & VR</li>
                                    <li>Games(2D,3D,AR,VR)</li>
                                    <li>Machine Learning</li>
                                    <li>Artificial intelligence</li>
                                    <li>Blockchain</li>
                                </ul>
                            </div>
                            <div class="services-image">
                                <img src="../wp-content/uploads/2020/08/reo-building-new.jpg" alt="REO services" />
                            </div>

                        </div>

                    </div>

                </div>


            </section>



            <section class="general-block " style="">

                <div class="container">
                    <div class="mx-auto" style="max-width: 100%;">
                        <blockquote>
                            <strong>Your limitation is your imagination.</strong>
                            <div class="name">Wayne Hydeman, President and CEO,Hydeman Development Inc.</div>
                        </blockquote>
                    </div>
                </div>

            </section>



            <div style="height:70px" aria-hidden="true" class="wp-block-spacer"></div>



            <section class="properties  padded" style="background-color: #e5e5e5">

                <div class="container">

                    <div class="mx-auto" style="max-width: 100%;">

                        <h2 style="text-align: center;">Featured Services</h2>



                        <ul class="properties">


                            <li>

                                <a>

                                    <h3>Constructions</h3>

                                    <img src="../wp-content/uploads/2020/07/property-healthcare.jpg" alt="Constraction" />

                                    <p>Centre Square Place<br />
                                        Regina, Canada</p>

                                </a>

                            </li>


                            <li>

                                <a>

                                    <h3>Developments</h3>

                                    <img src="../wp-content/uploads/2020/07/property-industrial.jpg" alt="Industrial" />

                                    <p>Rochdale Place<br />
                                        Regina, Saskatchewan</p>

                                </a>

                            </li>


                            <li>

                                <a>

                                    <h3>Softwares</h3>

                                    <img src="../wp-content/uploads/2020/07/application-development.png" alt="application-development" />

                                    <p> Toronto,Canada</p>

                                </a>

                            </li>


                            <li>

                                <a>

                                    <h3>Farmland</h3>

                                    <img src="../wp-content/uploads/2020/07/field.jpg" alt="Farmland" />

                                    <p>Central Alberta,
                                        Canada</p>

                                </a>

                            </li>


                            <li>

                                <a>

                                    <h3>RMG</h3>

                                    <img src="../wp-content/uploads/2020/07/garments.jpg" alt="RMG" />

                                    <p>Dhaka,
                                       Bangladesh</p>


                                </a>

                            </li>


                        </ul>


                    </div>









                </div>


            </section>



            <section class="services padded" style="">

                <div class="container">

                    <div class="mx-auto" style="max-width: 100%;">

                        <h2 style="text-align: center;">Explore Our Services</h2>



                        <ul class="services">


                            <li>

                                <a href="../commercial-brokerage/" target="">

                                    <img src="../wp-content/uploads/2020/07/service-commercial-brokerage.jpg"
                                        alt="Commercial Brokerage" />

                                    <h3>Commercial Brokerage</h3>

                                </a>

                            </li>


                            <li>

                                <a href="../property-management/" target="">

                                    <img src="../wp-content/uploads/2020/07/service-property-management.jpg"
                                        alt="Property Management" />

                                    <h3>Property<br>Management</h3>

                                </a>

                            </li>


                            <li>

                                <a href="../asset-management-financial-services/" target="">

                                    <img src="../wp-content/uploads/2020/07/service-asset-management.jpg"
                                        alt="Asset Management" />

                                    <h3>Asset Management<br>&#038; Financial<br>Services</h3>

                                </a>

                            </li>


                            <li>

                                <a href="../construction-project-management/" target="">

                                    <img src="../wp-content/uploads/2020/07/service-construction-management.jpg"
                                        alt="Construction Project Management" />

                                    <h3>Construction<br>Project<br>Management</h3>

                                </a>

                            </li>


                            <li>

                                <a href="#" target="">

                                    <img src="../wp-content/uploads/2020/07/service-software.png"
                                        alt="Software Development" />

                                    <h3>Software<br>Development</h3>

                                </a>

                            </li>


                            <li>

                                <a href="../readymade-garments/" target="">

                                    <img src="../wp-content/uploads/2020/07/service-dev-acquisitions.jpg"
                                        alt="Readymade Garments" />

                                    <h3>Readymade<br>Garments</h3>

                                </a>

                            </li>


                        </ul>






                    </div>









                </div>


            </section>



            <div style="height:30px" aria-hidden="true" class="wp-block-spacer"></div>
        </main>

        <section class="call">

            <div class="container">

                Contact a specialist today at <a class="phone-number" href="tel:+1 (306) 537-5656">+1 (306) 537-5656</a>
            </div>


        </section>

        <?php include('../footer.php')?>

        <nav id="pop-out-nav-wrapper">
            <p class="m-0"><a href="../index.html" id="nav-logo"></a> <a href="#" id="close"><img
                        src="../wp-content/themes/devsavvy/images/nav-close.svg" alt="close menu"
                        title="Close Menu"></a></p>
            <ul class="pop-out-nav-parent-wrapper">
                <li class="subParent   subitems"><a href="#" class="subnav-dropdown"></a> <a
                        href="../our-story/" class="subParent  ">About Us</a>
                    <ul class="subNav">
                        <li><a href="../our-story/">Our Story</a>
                        <li><a href="../our-team/">Team</a>
                    </ul>
                </li>
                <li class="subParent currentParent  subitems"><a href="#" class="subnav-dropdown"></a> <a
                        href="../commercial-brokerage/" class="subParent currentParent ">Services</a>
                    <ul class="subNav">
                        <li><a href="../commercial-brokerage/">Commercial Brokerage</a>
                        <li><a href="../property-management/">Property Management</a>
                        <li><a href="../asset-management-financial-services/">Asset Management &#038;
                                Financial Services</a>
                        <li><a href="../construction-project-management/">Construction Project Management</a>
                        <li><a class="current" href="index.html">REO Services</a>
                        <li><a href="../readymade-garments/">Readymade Garments</a>
                    </ul>
                </li>
                <li><a href="../listings/index.html">Listings</a>
                <li><a href="../blog/index.html">News</a>
                <li><a href="../contact/index.html">Contact</a>
                <li><a href="#">Tenant Login</a>
            </ul>
        </nav>
        <div id="overlay"></div>
    </div>

    <script type="text/javascript">
        _linkedin_partner_id = "3997052";
        window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];
        window._linkedin_data_partner_ids.push(_linkedin_partner_id);
    </script>
    <script type="text/javascript">
        (function (l) {
            if (!l) {
                window.lintrk = function (a, b) { window.lintrk.q.push([a, b]) };
                window.lintrk.q = []
            }
            var s = document.getElementsByTagName("script")[0];
            var b = document.createElement("script");
            b.type = "text/javascript"; b.async = true;
            b.src = "../../snap.licdn.com/li.lms-analytics/insight.min.js";
            s.parentNode.insertBefore(b, s);
        })(window.lintrk);
    </script>
    <noscript>
        <img height="1" width="1" style="display:none;" alt=""
            src="https://px.ads.linkedin.com/collect/?pid=3997052&amp;fmt=gif" />
    </noscript>

    <div id="pum-414" class="pum pum-overlay pum-theme-408 pum-theme-lightbox popmake-overlay click_open"
        data-popmake="{&quot;id&quot;:414,&quot;slug&quot;:&quot;tenant-login&quot;,&quot;theme_id&quot;:408,&quot;cookies&quot;:[],&quot;triggers&quot;:[{&quot;type&quot;:&quot;click_open&quot;,&quot;settings&quot;:{&quot;cookie_name&quot;:&quot;&quot;,&quot;extra_selectors&quot;:&quot;.tenant-popup&quot;}}],&quot;mobile_disabled&quot;:null,&quot;tablet_disabled&quot;:null,&quot;meta&quot;:{&quot;display&quot;:{&quot;stackable&quot;:false,&quot;overlay_disabled&quot;:false,&quot;scrollable_content&quot;:false,&quot;disable_reposition&quot;:false,&quot;size&quot;:&quot;normal&quot;,&quot;responsive_min_width&quot;:&quot;0%&quot;,&quot;responsive_min_width_unit&quot;:false,&quot;responsive_max_width&quot;:&quot;540px&quot;,&quot;responsive_max_width_unit&quot;:false,&quot;custom_width&quot;:&quot;540px&quot;,&quot;custom_width_unit&quot;:false,&quot;custom_height&quot;:&quot;380px&quot;,&quot;custom_height_unit&quot;:false,&quot;custom_height_auto&quot;:&quot;1&quot;,&quot;location&quot;:&quot;center&quot;,&quot;position_from_trigger&quot;:false,&quot;position_top&quot;:&quot;100&quot;,&quot;position_left&quot;:&quot;0&quot;,&quot;position_bottom&quot;:&quot;0&quot;,&quot;position_right&quot;:&quot;0&quot;,&quot;position_fixed&quot;:false,&quot;animation_type&quot;:&quot;fade&quot;,&quot;animation_speed&quot;:&quot;350&quot;,&quot;animation_origin&quot;:&quot;center top&quot;,&quot;overlay_zindex&quot;:false,&quot;zindex&quot;:&quot;1999999999&quot;},&quot;close&quot;:{&quot;text&quot;:&quot;&quot;,&quot;button_delay&quot;:&quot;0&quot;,&quot;overlay_click&quot;:false,&quot;esc_press&quot;:false,&quot;f4_press&quot;:false},&quot;click_open&quot;:[]}}"
        role="dialog" aria-hidden="true">

        <div id="popmake-414"
            class="pum-container popmake theme-408 pum-responsive pum-responsive-normal responsive size-normal">







            <div class="pum-content popmake-content" tabindex="0">
                <h2 style="text-align: center;">Tenant Login</h2>
                <p style="text-align: center;">You will be redirected to BuildingEngines, our trusted partner for
                    property management software. Please click continue to leave the McWhirter website and
                    <strong>proceed to the BuildingEngines tenant login page.</strong></p>
                <p style="text-align: center;"><a class="btn" href="https://www.requestcom.com/geofire/login"
                        target="_blank" rel="noopener noreferrer">Continue</a></p>
            </div>




            <button type="button" class="pum-close popmake-close" aria-label="Close">
                × </button>

        </div>

    </div>
    <script type='text/javascript'
        src='../wp-content/plugins/constant-contact-forms/assets/js/ctct-plugin-recaptcha-v2.min1dd9.js?ver=1.13.0'
        id='recaptcha-v2-js'></script>
    <script async="async" defer type='text/javascript'
        src='../../www.google.com/recaptcha/api0c32.js?onload=renderReCaptcha&amp;render=explicit&amp;ver=1.13.0'
        id='recaptcha-lib-v2-js'></script>
    <script type='text/javascript'
        src='../wp-content/plugins/constant-contact-forms/assets/js/ctct-plugin-frontend.min1dd9.js?ver=1.13.0'
        id='ctct_frontend_forms-js'></script>
    <script type='text/javascript' src='../wp-includes/js/jquery/ui/core.min3f14.js?ver=1.13.2'
        id='jquery-ui-core-js'></script>
    <script type='text/javascript' id='popup-maker-site-js-extra'>
        /* <![CDATA[ */
        var pum_vars = { "version": "1.16.14", "pm_dir_url": "https:\/\/mcwrealty.com\/wp-content\/plugins\/popup-maker\/", "ajaxurl": "https:\/\/mcwrealty.com\/wp-admin\/admin-ajax.php", "restapi": "https:\/\/mcwrealty.com\/wp-json\/pum\/v1", "rest_nonce": null, "default_theme": "408", "debug_mode": "", "disable_tracking": "", "home_url": "\/", "message_position": "top", "core_sub_forms_enabled": "1", "popups": [], "analytics_route": "analytics", "analytics_api": "https:\/\/mcwrealty.com\/wp-json\/pum\/v1" };
        var pum_sub_vars = { "ajaxurl": "https:\/\/mcwrealty.com\/wp-admin\/admin-ajax.php", "message_position": "top" };
        var pum_popups = { "pum-414": { "triggers": [{ "type": "click_open", "settings": { "cookie_name": "", "extra_selectors": ".tenant-popup" } }], "cookies": [], "disable_on_mobile": false, "disable_on_tablet": false, "atc_promotion": null, "explain": null, "type_section": null, "theme_id": "408", "size": "normal", "responsive_min_width": "0%", "responsive_max_width": "540px", "custom_width": "540px", "custom_height_auto": true, "custom_height": "380px", "scrollable_content": false, "animation_type": "fade", "animation_speed": "350", "animation_origin": "center top", "open_sound": "none", "custom_sound": "", "location": "center", "position_top": "100", "position_bottom": "0", "position_left": "0", "position_right": "0", "position_from_trigger": false, "position_fixed": false, "overlay_disabled": false, "stackable": false, "disable_reposition": false, "zindex": "1999999999", "close_button_delay": "0", "fi_promotion": null, "close_on_form_submission": false, "close_on_form_submission_delay": "0", "close_on_overlay_click": false, "close_on_esc_press": false, "close_on_f4_press": false, "disable_form_reopen": false, "disable_accessibility": false, "theme_slug": "lightbox", "id": 414, "slug": "tenant-login" } };
/* ]]> */
    </script>
    <script type='text/javascript'
        src='../wp-content/uploads/pum/pum-site-scripts7907.js?defer&amp;generated=1668451767&amp;ver=1.16.14'
        id='popup-maker-site-js'></script>
</body>

<!-- /reo-services30 Nov 2022 15:29:51 GMT -->

</html>